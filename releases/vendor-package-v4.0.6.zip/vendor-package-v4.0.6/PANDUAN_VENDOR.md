# Paket Update v4.0.6 — Untuk Vendor / Distributor

## Isi Paket

| File | Keterangan |
|------|------------|
| `cbt-school-enterprise-v4.0.6.zip` | File update (dist frontend) — upload ke GitHub Releases |
| `migration-v4.0.6.sql` | Script SQL perbaikan database |
| `release-info.json` | Referensi metadata release |

## Cara Deploy ke Sistem Update Otomatis

### Langkah 1: Upload ZIP ke GitHub Releases
Upload `cbt-school-enterprise-v4.0.6.zip` ke GitHub Releases dengan tag `v4.0.6`.
Salin URL download-nya.

### Langkah 2: Daftarkan Release di Server Vendor
```json
{
  "version": "4.0.6",
  "release_notes": "Perbaikan kritis: Fix timeout saat impor/sinkronisasi data pengguna massal (500+ siswa). Impor via Google Sheet dan Excel sekarang berhasil tanpa error timeout.",
  "download_url": "<URL dari Langkah 1>",
  "sql_migration": "<isi dengan seluruh konten file migration-v4.0.6.sql>"
}
```

## Daftar Perbaikan Database (migration-v4.0.6.sql)

| Fungsi | Perbaikan |
|--------|-----------|
| `sync_all_users` | + `statement_timeout=0`, bcrypt cost=10→6 |
| `admin_import_users(json)` | + `statement_timeout=0`, bcrypt cost=10→6 |
| `admin_import_users(jsonb)` | + `statement_timeout=0`, bcrypt cost=10→6 |
| `admin_reset_student_password` | + `statement_timeout=0`, bcrypt cost=10→6 |
| `admin_upsert_user` | + `statement_timeout=0`, bcrypt cost=10→6 |

---
*Dikembangkan oleh: Ari Wijaya — CBT School Enterprise*
