-- ============================================================
-- CBT SCHOOL ENTERPRISE — Migration v4.0.5
-- Tanggal  : 09 Maret 2026
-- Perbaikan: Fix timeout impor data pengguna massal
--
-- Masalah  : Fungsi import/sync pengguna menggunakan bcrypt
--            cost=10 (~150ms/hash). Untuk 953 siswa = ~143 detik
--            → melebihi statement_timeout 8 detik → GAGAL.
--
-- Solusi   :
--   1. SET statement_timeout = 0 pada semua fungsi SECURITY DEFINER
--   2. gen_salt('bf', 6) → cost=6, ~6ms/hash (16x lebih cepat)
--      953 siswa × 6ms ≈ 6 detik → berhasil
-- ============================================================

-- ── 1. sync_all_users (Google Sheet Sync) ───────────────────
CREATE OR REPLACE FUNCTION public.sync_all_users(users_data json)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public, auth, extensions
                 SET statement_timeout = 0
AS $$
DECLARE
  deleted_count int := 0;
  updated_count int := 0;
  inserted_count int := 0;
  v_domain text;
BEGIN
  SELECT email_domain INTO v_domain FROM public.app_config LIMIT 1;
  IF v_domain IS NULL OR v_domain = '' THEN
    v_domain := 'smkn8sby.sch.id';
  END IF;

  CREATE TEMP TABLE IF NOT EXISTS incoming_users (
    username text, password text, "fullName" text, nisn text, class text, major text, gender text, religion text, "photoUrl" text
  ) ON COMMIT DROP;

  TRUNCATE incoming_users;
  INSERT INTO incoming_users SELECT * FROM json_populate_recordset(null::incoming_users, users_data);

  WITH deleted_users AS (
    DELETE FROM auth.users
    WHERE email NOT LIKE '%admin%' AND email NOT LIKE '%guru%'
      AND id IN (
        SELECT u.id FROM public.users u
        WHERE u.nisn IS NOT NULL AND NOT EXISTS (SELECT 1 FROM incoming_users i WHERE i.nisn = u.nisn)
      )
    RETURNING *
  ) SELECT count(*) INTO deleted_count FROM deleted_users;

  WITH updated_rows AS (
    UPDATE public.users pu
    SET full_name = i."fullName", class = i.class, major = i.major, gender = i.gender,
        religion = i.religion, photo_url = i."photoUrl", updated_at = now()
    FROM incoming_users i WHERE pu.nisn = i.nisn
    RETURNING pu.id
  ) SELECT count(*) INTO updated_count FROM updated_rows;

  WITH new_users AS (
    INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, raw_user_meta_data, aud, role)
    SELECT
      gen_random_uuid(),
      i.nisn || '@' || v_domain,
      crypt(COALESCE(i.password, i.nisn), gen_salt('bf', 6)),
      now(),
      jsonb_build_object('full_name', i."fullName", 'nisn', i.nisn, 'class', i.class,
        'major', i.major, 'gender', i.gender, 'religion', i.religion, 'photo_url', i."photoUrl", 'role', 'student'),
      'authenticated', 'authenticated'
    FROM incoming_users i
    WHERE NOT EXISTS (SELECT 1 FROM public.users pu WHERE pu.nisn = i.nisn)
    RETURNING *
  ) SELECT count(*) INTO inserted_count FROM new_users;

  RETURN json_build_object('deleted', deleted_count, 'updated', updated_count, 'inserted', inserted_count);
END;
$$;

GRANT EXECUTE ON FUNCTION public.sync_all_users(json) TO authenticated;


-- ── 2. admin_import_users — versi json (Import Excel) ───────
CREATE OR REPLACE FUNCTION public.admin_import_users(users_data json)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public, extensions
                 SET statement_timeout = 0
AS $$
DECLARE
  updated_count int;
  inserted_count int;
  v_domain text := 'smpn2demak.sch.id';
BEGIN
  IF NOT (SELECT auth.email() = 'admin@cbtschool.com') THEN
    RAISE EXCEPTION '403: Forbidden';
  END IF;

  CREATE TEMP TABLE incoming_users_import (
    "username" text, "password" text, "fullName" text, "nisn" text,
    "class" text, "major" text, "gender" text, "religion" text, "photoUrl" text, "role" text
  ) ON COMMIT DROP;

  INSERT INTO incoming_users_import
  SELECT * FROM json_populate_recordset(null::incoming_users_import, users_data);

  UPDATE incoming_users_import SET role = 'student' WHERE role IS NULL OR role = '';

  IF EXISTS (SELECT 1 FROM incoming_users_import WHERE role NOT IN ('student', 'teacher', 'admin')) THEN
     RAISE EXCEPTION 'Data tidak valid: Role harus student, teacher, atau admin.';
  END IF;

  WITH updated_public_users AS (
      UPDATE public.users pu
      SET full_name = i."fullName", class = i.class, major = i.major, gender = i.gender,
          religion = i.religion, photo_url = COALESCE(i."photoUrl", pu.photo_url),
          username = i."username", password_text = i."password", qr_login_password = i."password",
          role = i."role", updated_at = now()
      FROM incoming_users_import i
      WHERE pu.nisn = i.nisn
      RETURNING pu.id
  )
  SELECT count(*) INTO updated_count FROM updated_public_users;

  UPDATE auth.users au
  SET email = CASE WHEN i."username" LIKE '%@%' THEN i."username" ELSE i."username" || '@' || v_domain END,
      encrypted_password = crypt(i."password", gen_salt('bf', 6)),
      raw_user_meta_data = au.raw_user_meta_data || jsonb_build_object(
            'full_name', i."fullName", 'nisn', i.nisn, 'class', i.class, 'major', i.major, 'role', i."role"),
      updated_at = now()
  FROM incoming_users_import i
  JOIN public.users pu ON i.nisn = pu.nisn
  WHERE au.id = pu.id;

  WITH new_auth_users AS (
    INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, raw_user_meta_data, aud, role)
    SELECT uuid_generate_v4(),
      CASE WHEN i."username" LIKE '%@%' THEN i."username" ELSE i."username" || '@' || v_domain END,
      crypt(i."password", gen_salt('bf', 6)),
      now(),
      jsonb_build_object('full_name', i."fullName", 'nisn', i.nisn, 'class', i.class, 'major', i.major,
          'gender', i.gender, 'religion', i.religion,
          'photo_url', COALESCE(i."photoUrl", 'https://ui-avatars.com/api/?name=' || i."fullName"),
          'password_text', i."password", 'username_excel', i."username", 'role', i."role"),
      'authenticated', 'authenticated'
    FROM incoming_users_import i
    WHERE NOT EXISTS (SELECT 1 FROM public.users pu WHERE pu.nisn = i.nisn)
    RETURNING id, raw_user_meta_data
  )
  INSERT INTO public.users (id, username, full_name, nisn, class, major, gender, religion, photo_url, password_text, qr_login_password, role)
  SELECT nau.id, (nau.raw_user_meta_data->>'username_excel'), (nau.raw_user_meta_data->>'full_name'),
    (nau.raw_user_meta_data->>'nisn'), (nau.raw_user_meta_data->>'class'), (nau.raw_user_meta_data->>'major'),
    (nau.raw_user_meta_data->>'gender'), (nau.raw_user_meta_data->>'religion'), (nau.raw_user_meta_data->>'photo_url'),
    (nau.raw_user_meta_data->>'password_text'), (nau.raw_user_meta_data->>'password_text'), (nau.raw_user_meta_data->>'role')
  FROM new_auth_users nau;

  SELECT count(*) INTO inserted_count FROM incoming_users_import i WHERE NOT EXISTS (SELECT 1 FROM public.users pu WHERE pu.nisn = i.nisn);

  RETURN json_build_object('updated', updated_count, 'inserted', inserted_count, 'total', updated_count + inserted_count);
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_import_users(json) TO authenticated;


-- ── 3. admin_import_users — versi jsonb (Import Excel v2) ───
DROP FUNCTION IF EXISTS public.admin_import_users(jsonb);

CREATE FUNCTION public.admin_import_users(users_data jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public, auth, extensions
                 SET statement_timeout = 0
AS $$
DECLARE
  user_record record;
  v_user_id uuid;
BEGIN
  FOR user_record IN
    SELECT * FROM jsonb_to_recordset(users_data) AS x(
      username text, password text, "fullName" text, nisn text,
      class text, major text, gender text, religion text, "photoUrl" text, role text
    )
  LOOP
    SELECT id INTO v_user_id FROM public.users WHERE username = user_record.username;

    IF v_user_id IS NULL THEN
      v_user_id := gen_random_uuid();
      INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, raw_user_meta_data, aud, role)
      VALUES (v_user_id, user_record.username,
        crypt(COALESCE(user_record.password, user_record.nisn), gen_salt('bf', 6)),
        now(),
        jsonb_build_object('full_name', user_record."fullName", 'nisn', user_record.nisn,
          'class', user_record.class, 'major', user_record.major, 'gender', user_record.gender,
          'religion', user_record.religion, 'photo_url', user_record."photoUrl", 'role', user_record.role),
        'authenticated', 'authenticated');
      INSERT INTO public.users (id, username, password_text, full_name, nisn, class, major, gender, religion, photo_url, role, qr_login_password)
      VALUES (v_user_id, user_record.username, COALESCE(user_record.password, user_record.nisn),
        user_record."fullName", user_record.nisn, user_record.class, user_record.major,
        user_record.gender, user_record.religion, user_record."photoUrl",
        COALESCE(user_record.role, 'student'), COALESCE(user_record.password, user_record.nisn))
      ON CONFLICT (username) DO UPDATE SET
        full_name = EXCLUDED.full_name, nisn = EXCLUDED.nisn, class = EXCLUDED.class,
        major = EXCLUDED.major, gender = EXCLUDED.gender, religion = EXCLUDED.religion,
        photo_url = EXCLUDED.photo_url, role = EXCLUDED.role,
        password_text = CASE WHEN user_record.password IS NOT NULL THEN user_record.password ELSE public.users.password_text END,
        qr_login_password = CASE WHEN user_record.password IS NOT NULL THEN user_record.password ELSE public.users.qr_login_password END;
    ELSE
      UPDATE auth.users SET
        encrypted_password = CASE WHEN user_record.password IS NOT NULL THEN crypt(user_record.password, gen_salt('bf', 6)) ELSE encrypted_password END,
        raw_user_meta_data = jsonb_build_object('full_name', user_record."fullName", 'nisn', user_record.nisn,
          'class', user_record.class, 'major', user_record.major, 'gender', user_record.gender,
          'religion', user_record.religion, 'photo_url', user_record."photoUrl", 'role', user_record.role)
      WHERE id = v_user_id;

      UPDATE public.users SET
        full_name = user_record."fullName", nisn = user_record.nisn, class = user_record.class,
        major = user_record.major, gender = user_record.gender, religion = user_record.religion,
        photo_url = user_record."photoUrl", role = COALESCE(user_record.role, role),
        password_text = CASE WHEN user_record.password IS NOT NULL THEN user_record.password ELSE password_text END,
        qr_login_password = CASE WHEN user_record.password IS NOT NULL THEN user_record.password ELSE qr_login_password END
      WHERE id = v_user_id;
    END IF;
  END LOOP;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_import_users(jsonb) TO authenticated;


-- ── 4. admin_reset_student_password ─────────────────────────
CREATE OR REPLACE FUNCTION public.admin_reset_student_password(p_user_id uuid, p_new_password text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public, auth, extensions
                 SET statement_timeout = 0
AS $$
BEGIN
  UPDATE auth.users
  SET encrypted_password = extensions.crypt(p_new_password, extensions.gen_salt('bf', 6)),
      updated_at = now()
  WHERE id = p_user_id;

  UPDATE public.users
  SET password_text = p_new_password, qr_login_password = p_new_password
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_reset_student_password(uuid, text) TO authenticated;


-- ── 5. admin_upsert_user ─────────────────────────────────────
DROP FUNCTION IF EXISTS public.admin_upsert_user(uuid,text,text,text,text,text,text,text,text,text,text);

CREATE FUNCTION public.admin_upsert_user(
  p_id uuid DEFAULT NULL, p_username text DEFAULT NULL, p_password text DEFAULT NULL,
  p_full_name text DEFAULT NULL, p_nisn text DEFAULT NULL, p_class text DEFAULT NULL,
  p_major text DEFAULT NULL, p_gender text DEFAULT NULL, p_religion text DEFAULT NULL,
  p_photo_url text DEFAULT NULL, p_role text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public, auth, extensions
                 SET statement_timeout = 0
AS $$
DECLARE
  v_user_id uuid;
  v_email text;
  v_password text;
BEGIN
  v_password := COALESCE(p_password, p_nisn, 'password123');

  IF p_id IS NULL THEN
    v_user_id := uuid_generate_v4();
    v_email := p_username;

    INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, created_at, updated_at, raw_user_meta_data, aud, role)
    VALUES (v_user_id, v_email,
      extensions.crypt(v_password, extensions.gen_salt('bf', 6)),
      now(), now(), now(),
      jsonb_build_object('full_name', p_full_name, 'nisn', p_nisn, 'class', p_class,
        'major', p_major, 'gender', p_gender, 'religion', p_religion,
        'photo_url', p_photo_url, 'role', p_role, 'password_text', v_password),
      'authenticated', 'authenticated');

    INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, created_at, updated_at)
    VALUES (v_email, v_user_id, jsonb_build_object('sub', v_user_id::text, 'email', v_email), 'email', now(), now())
    ON CONFLICT (provider_id, provider) DO NOTHING;

  ELSE
    UPDATE auth.users SET
      email = COALESCE(p_username, email),
      encrypted_password = CASE WHEN p_password IS NOT NULL
        THEN extensions.crypt(p_password, extensions.gen_salt('bf', 6))
        ELSE encrypted_password END,
      updated_at = now(),
      raw_user_meta_data = jsonb_build_object('full_name', p_full_name, 'nisn', p_nisn, 'class', p_class,
        'major', p_major, 'gender', p_gender, 'religion', p_religion,
        'photo_url', p_photo_url, 'role', p_role, 'password_text', COALESCE(p_password, p_nisn))
    WHERE id = p_id;

    UPDATE auth.identities SET
      provider_id = p_username,
      identity_data = jsonb_build_object('sub', p_id::text, 'email', p_username),
      updated_at = now()
    WHERE user_id = p_id AND provider = 'email';

    UPDATE public.users SET
      username = COALESCE(p_username, username), full_name = p_full_name,
      nisn = p_nisn, class = p_class, major = p_major, gender = p_gender,
      religion = p_religion, photo_url = p_photo_url, role = p_role,
      password_text = CASE WHEN p_password IS NOT NULL THEN p_password ELSE password_text END,
      qr_login_password = CASE WHEN p_password IS NOT NULL THEN p_password ELSE qr_login_password END,
      updated_at = now()
    WHERE id = p_id;
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_upsert_user(uuid,text,text,text,text,text,text,text,text,text,text) TO authenticated;
